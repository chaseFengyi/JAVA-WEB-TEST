package com;

import java.io.Serializable;

public class UserClass  implements Serializable{
       private int userId;
       private String usersName;
       private String usersPass;
       private String usersRepass;
       private String usersPassQuestion;
       private String usersPassReply;
       private String usersTrueName;
       private String usersAddress;
       private String usersPhone;
       private String usersE_mail;
	public int getUsersId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUsersName() {
		return usersName;
	}
	public void setUsersName(String usersName) {
		this.usersName = usersName;
	}
	public String getUsersPass() {
		return usersPass;
	}
	public void setUsersPass(String usersPass) {
		this.usersPass = usersPass;
	}
	public String getUsersRepass() {
		return usersRepass;
	}
	public void setUsersRepass(String usersRepass) {
		this.usersRepass = usersRepass;
	}
	public String getUsersPassQuestion() {
		return usersPassQuestion;
	}
	public void setUsersPassQuestion(String usersPassQuestion) {
		this.usersPassQuestion = usersPassQuestion;
	}
	public String getUsersPassReply() {
		return usersPassReply;
	}
	public void setUsersPassReply(String usersPassReply) {
		this.usersPassReply = usersPassReply;
	}
	public String getUsersTrueName() {
		return usersTrueName;
	}
	public void setUsersTrueName(String usersTrueName) {
		this.usersTrueName = usersTrueName;
	}
	public String getUsersAddress() {
		return usersAddress;
	}
	public void setUsersAddress(String usersAddress) {
		this.usersAddress = usersAddress;
	}
	public String getUsersPhone() {
		return usersPhone;
	}
	public void setUsersPhone(String usersPhone) {
		this.usersPhone = usersPhone;
	}
	public String getUsersE_mail() {
		return usersE_mail;
	}
	public void setUsersE_mail(String usersEMail) {
		usersE_mail = usersEMail;
	}
       
}
