package com.myProject.domain;

import java.util.LinkedHashMap;
import java.util.Map;


//�������ﳵ
public class Cart {

	//���湺�ﳵ��������Ʒ,CartItem����ĳһ��Ʒ���ж��ٴ�
	private Map<String,CartItem> map = new LinkedHashMap();
	private double price;
	
	public void add(Book book){
		
		CartItem item = map.get(book.getId());
		if(item != null){
			item.setQuantity(item.getQuantity() +1);
		}else{
			item = new CartItem();
			item.setBook(book);
			item.setQuantity(1);
			map.put(book.getId(), item);
		}
		
	}
	public Map<String, CartItem> getMap() {
		return map;
	}
	public void setMap(Map<String, CartItem> map) {
		this.map = map;
	}
	public double getPrice() {
		double totalPrice = 0;
		for(Map.Entry<String, CartItem> me : map.entrySet()){
			CartItem item = me.getValue();
			totalPrice += item.getPrice();
		}
		
		return totalPrice;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
