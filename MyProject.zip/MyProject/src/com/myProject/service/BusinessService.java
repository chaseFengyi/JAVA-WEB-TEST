package com.myProject.service;

import java.util.Map;

import com.myProject.dao.BookDao;
import com.myProject.domain.Book;
import com.myProject.domain.Cart;

public class BusinessService {
	
	BookDao dao = new BookDao();
	
	//�г�������ķ���
	public Map getAllBook(){
		
		
		return dao.getAll();
	}

	public void buyBook(String bookid, Cart cart) {

		Book book = dao.find(bookid);
		cart.add(book);
		
	}
}
