package com;

import java.io.Serializable;

public class OrdersClass implements Serializable {
	private int ordersId;
    private String usersName;
    private float ordersPrice;
    private String ordersDatetime;
	public int getOrdersId() {
		return ordersId;
	}
	public void setOrdersId(int ordersId) {
		this.ordersId = ordersId;
	}
	public String getUsersName() {
		return usersName;
	}
	public void setUsersName(String usersName) {
		this.usersName = usersName;
	}
	public float getOrdersPrice() {
		return ordersPrice;
	}
	public void setOrdersPrice(float ordersPrice) {
		this.ordersPrice = ordersPrice;
	}
	public String getOrdersDatetime() {
		return ordersDatetime;
	}
	public void setOrdersDatetime(String ordersDatetime) {
		this.ordersDatetime = ordersDatetime;
	}
    
}
