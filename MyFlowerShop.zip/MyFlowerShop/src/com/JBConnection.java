package com;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JBConnection {       
	 
	/*public static  java.sql.Connection  getConnection()  throws SQLException{
		  String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";  //����JDBC����
		  String dbURL = "jdbc:sqlserver://localhost:1433; DatabaseName=buyFlowers";  //���ӷ����������ݿ�test
		  String userName = "sa";  //Ĭ���û���
		  String userPwd = "123";  //����
		try
	      {
			  
			  Connection dbConn;
             Class.forName(driverName);
          
	        dbConn = DriverManager.getConnection(dbURL, userName, userPwd);
	        System.out.println("���ݿ���سɹ���");
	       return dbConn;

	      }
	      catch(Exception e)
	      {
	        e.printStackTrace();
	       return null;
	      }
	}*/
	private static String username = "root";
	private static String password = "123456";
	private static String driver = "com.mysql.jdbc.Driver";
	private static String url = "jdbc:mysql://localhost:3306/buyFlowers";

	private static Connection conn;

	// ע������
	static {
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("ע������ʧ��");
		}
	}

	// ��������
	public static Connection getConnection() {
		try {
			conn = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}

	// �ͷ���Դ
	public void free(Connection conn, PreparedStatement ps, ResultSet rs) {
		try {
			if (rs != null) {
				rs.close();
			}
		} catch (SQLException e) {
			System.out.println("�ͷ���Դʧ��!");
			System.exit(-1);
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				System.out.println("�ͷ���Դʧ��!");
				System.exit(-1);
				e.printStackTrace();
			} finally {
				try {
					if (conn != null) {
						conn.close();
					}
				} catch (SQLException e) {
					System.out.println("�ͷ���Դʧ��!");
					System.exit(-1);
					e.printStackTrace();
				}
			}
		}
	}

}
