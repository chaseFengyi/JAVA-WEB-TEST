package com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class GoodsBean {
	private Connection con;
	PageNumber pagenumber=new PageNumber();
	int rowCount=1;
	int showPage=16;
	int pageCount=1;
	public GoodsBean()
	{
		try{
			con=JBConnection.getConnection();
			System.out.println("���ݿ���سɹ�");
			
		}catch (Exception e) {
		   e.printStackTrace();
		}
	}
	public int getRowCount()
	{
		return rowCount;
	}
	//��ѯȫ����Ʒ����Ϣ
	public int getAllPage()
	{
		try {
		Statement statement=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		 ResultSet resultset=statement.executeQuery("select * from Goods");
		 resultset.last();
		 rowCount=resultset.getRow();  //resultset�ķ���
		 pagenumber.setPageCount(rowCount, showPage);
		 pageCount=pagenumber.getPageCount();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return pageCount;
	}
	//������Ʒ�������Ʒ��Ϣ�ķ���
	public int getAllPageBySort(String s)
	{
		try {
		   Statement statement=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		  ResultSet result=statement.executeQuery("select * from Goods where sortName='"+s+" ' ");
		  result.last();
		  rowCount=result.getRow();
		  pagenumber.setPageCount(rowCount, showPage);
		  pageCount=pagenumber.getPageCount();
		} catch (Exception e) {
		   e.printStackTrace();
		}
		return pageCount;
	}
	//������Ʒ�۸�����Ʒ��Ϣ�ķ���
//	public int getAllPageByPrice(String s)
//	{
//		int a=s.indexOf("-");
//		float one=Float.parseFloat(s.substring(0,a));
//		float two=Float.parseFloat(s.substring(a+1));
//		try {
//			
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//	}
	//������Ʒ���Ļ����Ʒ��Ϣ�ķ���
//	public int getAllPageByMaterial(String s)
//	{
//		try {
//			Statement stam=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
//			ResultSet  result=stam.executeQuery("select * from Goods where goodsmaterial like '%"+s+"%'");
//		   result.last();
//		   rowCount=result.getRow();
//		   pagenumber.setPageCount(rowCount, showPage);
//		   pageCount=pagenumber.getPageCount();
//		} catch (Exception e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
//		return pageCount;
//	}
	//����������Ʒ��Ϣ�ķ���
	public void addGoods(GoodsClass  goods)
	{
		try {
			PreparedStatement preparedStatement=con.prepareStatement("insert into goods values(?,?,?,?,?,?,?,?,?,?)");
			preparedStatement.setString(1,goods.getGoodsName());
			preparedStatement.setString(2, goods.getGoodsmateratial());
			preparedStatement.setString(3, goods.getGoodsPackage());
			preparedStatement.setString(4, goods.getGoodsLanguage());
			preparedStatement.setFloat(5, goods.getGoodsPrice());
			preparedStatement.setString(6, goods.getGoodsCent());
			preparedStatement.setString(7, goods.getGoodsScope());
			preparedStatement.setString(8, goods.getGoodsPlace());
			preparedStatement.setString(9, goods.getGoodsHabitus());
			preparedStatement.setString(10, goods.getSortName());
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	//ɾ����Ʒ��Ϣ
		public void deleteGoods(String s)
		{
		    try {
				int i=Integer.parseInt(s);
				Statement statement=con.createStatement();
				statement.execute("delete from goods where goodsId=' " +i+" ' ");
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}	
		
	}
		//�����ȡ��Ʒ��Ϣ�ķ���
		public GoodsClass getGoodsInfo(String s)
		{
		    GoodsClass goods=new GoodsClass();
		    try {
				Statement statement=con.createStatement();
				ResultSet resultSet=statement.executeQuery("select * from goods where goodsId=' " +s+" ' ");
				while(resultSet.next())
				{
					int i=resultSet.getInt(1);
					String s1=resultSet.getString(2);
					String s2=resultSet.getString(3);
					String s3=resultSet.getString(4);
					String s4=resultSet.getString(5);
					float f=resultSet.getFloat(6);
					String s5=resultSet.getString(7);
					String s6=resultSet.getString(8);
					String s7=resultSet.getString(9);
					String s8=resultSet.getString(10);
					String s9=resultSet.getString(11);
					goods.setGoodsId(i);
					goods.setGoodsName(s1);
					goods.setGoodsmateratial(s2);
					goods.setGoodsPackage(s3);
					goods.setGoodsLanguage(s4);
					goods.setGoodsPrice(f);
					goods.setGoodsCent(s5);
					goods.setGoodsScope(s6);
					goods.setGoodsPlace(s7);
					goods.setGoodsHabitus(s8);
					goods.setSortName(s9);
					
				}
			} catch (Exception e) {
			    e.printStackTrace();
			}
			return goods;
		}
		public void modifyGoods(GoodsClass goods)
		{
			try {
				PreparedStatement preparedStatement=con.prepareStatement("update goods set goodsName=?," +
						"goodsmaterial=?,goodsPackage=?,goodsLanguage=?,goodsPrice=?,goodsCent=?,goodsScope=?," +
						"goodsPlace=?,goodsHabitus=?,sortName=? where goodsId=?");
				preparedStatement.setString(1,goods.getGoodsName());
				preparedStatement.setString(2, goods.getGoodsmateratial());
				preparedStatement.setString(3, goods.getGoodsPackage());
				preparedStatement.setString(4, goods.getGoodsLanguage());
				preparedStatement.setFloat(5, goods.getGoodsPrice());
				preparedStatement.setString(6, goods.getGoodsCent());
				preparedStatement.setString(7, goods.getGoodsScope());
				preparedStatement.setString(8, goods.getGoodsPlace());
				preparedStatement.setString(9, goods.getGoodsHabitus());
				preparedStatement.setString(10, goods.getSortName());
				preparedStatement.setInt(11, goods.getGoodsId());
			} catch (Exception e) {
				
				e.printStackTrace();
			}
		}
}
