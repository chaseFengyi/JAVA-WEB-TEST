package com.servlet;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.domain.Resource;
import com.service.ResourceService;

public class UpdateResourceServlet extends HttpServlet {

	private ResourceService resourceService = new ResourceService();
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		String id = req.getParameter("id");
		String name = req.getParameter("resourceName");
		String description = req.getParameter("comments");
		String createTime = req.getParameter("createTime");
		String status = req.getParameter("status");
		
		System.out.println(id);
		System.out.println(name);
		Resource resource = new Resource();
		resource.setId(id);
		resource.setName(name);
		resource.setDescription(description);
		resource.setCreateTime(createTime);
		resource.setStatus(status);
		
		resourceService.updateResource(resource);
		
		req.getRequestDispatcher("/resource/ListResourceServlet").forward(req, resp);

			
	}
	
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, resp);
	}
}
