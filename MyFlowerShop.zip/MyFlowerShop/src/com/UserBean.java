package com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

public class UserBean {
	private Connection con;
	UserClass user;

	public UserBean() {
		try {
			con = JBConnection.getConnection();
			System.out.println("���ݿ���سɹ���");
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void setUserInfo(UserClass user) {
		this.user = user;
	}
    public void addUserInfo() throws Exception {
		try {
			PreparedStatement stm = con
					.prepareStatement("insert into users(usersName,usersPass,usersRepass,usersPassQuestion,usersPassReply," +
							"usersTrueName,usersAddress,usersPhone,usersE_mail)" +
							" values(?,?,?,?,?,?,?,?,?)");
			System.out.println("uuuu--->"+user.getUsersName());
			String usersName=new String(user.getUsersName().getBytes("ISO-8859-1"),"utf-8");
			System.out.println(usersName);
			stm.setString(1, usersName);// ����һ���ʺŸ�ֵΪuser.getUsersName()��ֵ
			
			stm.setString(2, user.getUsersPass());
			stm.setString(3, user.getUsersRepass());
			stm.setString(4, user.getUsersPassQuestion());
			stm.setString(5, user.getUsersPassReply());
			String trueName=new String(user.getUsersTrueName().getBytes("ISO-8859-1"),"utf-8");
			stm.setString(6, trueName);
			String userAddress=new String(user.getUsersAddress().getBytes("ISO-8859-1"),"utf-8");
			stm.setString(7, userAddress);
			stm.setString(8, user.getUsersPhone()); 
			stm.setString(9, user.getUsersE_mail());
			try {
				stm.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public boolean checkUserInfo() throws Exception {
		boolean flag = false;
		try {
			PreparedStatement stam = con
					.prepareStatement("select * from users where usersName=? and usersPass=?");
			stam.setString(1, user.getUsersName());
			stam.setString(2, user.getUsersPass());
			ResultSet result = stam.executeQuery(); // executeQuery()���ص��ǽ����
			if (result.next()) {
				flag = true;
			}
			result.close();
			stam.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw e;
		}
		return flag;
	}

	public UserClass getUserInfo() throws Exception {
		UserClass user1 = new UserClass();
		try {
			PreparedStatement stam = con
					.prepareStatement("select * from users where usersName=? and usersPass=?");
			stam.setString(1, user.getUsersName());
			stam.setString(2, user.getUsersPass());
			ResultSet result = stam.executeQuery();
			while (result.next()) {
				int usersid = result.getInt(1);
				String name = result.getString(2);
				String pass = result.getString(3);
				String repass = result.getString(4);
				String question = result.getString(5);
				String reply = result.getString(6);
				String truename = result.getString(7);
				String address = result.getString(8);
				String phone = result.getString(9);
				String email = result.getString(10);
				user1.setUserId(usersid);
				user1.setUsersName(name);
				user1.setUsersPass(pass);
				user1.setUsersRepass(repass);
				user1.setUsersPassQuestion(question);
				user1.setUsersAddress(address);
				user1.setUsersPassReply(reply);
				user1.setUsersTrueName(truename);
				user1.setUsersE_mail(email);
				user1.setUsersPhone(phone);
			}
			result.close();
			stam.close();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return user1;
	}

	/* �õ�ȫ�����û���Ϣ */
	public ArrayList<UserClass> getAllUserInfo() {
		UserClass user;
		ArrayList<UserClass> arraylist = new ArrayList<UserClass>();

		try {
			Statement statement = con.createStatement();
			ResultSet result = statement.executeQuery("select * from users");
			while (result.next()) {
				user = new UserClass();
				int usersid = result.getInt(1);
				String name = result.getString(2);
				String pass = result.getString(3);
				String repass = result.getString(4);
				String question = result.getString(5);
				String reply = result.getString(6);
				String truename = result.getString(7);
				String address = result.getString(8);
				String phone = result.getString(9);
				String email = result.getString(10);
				user.setUserId(usersid);
				user.setUsersName(name);
				user.setUsersPass(pass);
				user.setUsersRepass(repass);
				user.setUsersPassQuestion(question);
				user.setUsersAddress(address);
				user.setUsersPassReply(reply);
				user.setUsersTrueName(truename);
				user.setUsersE_mail(email);
				user.setUsersPhone(phone);
				arraylist.add(user);
			}
			result.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return arraylist;
	}

	public Collection<UserClass> getUserByUserId(String s) {

		int a = Integer.parseInt(s);
		UserClass user = new UserClass();
		ArrayList<UserClass> arraylist = new ArrayList<UserClass>();
		try {
			PreparedStatement stam = con
					.prepareStatement("select *  from users where userId='" + a+ "'");
			ResultSet result = stam.executeQuery();
			while (result.next()) {
				int usersid = result.getInt(1);
				String name = result.getString(2);
				String pass = result.getString(3);
				String repass = result.getString(4);
				String question = result.getString(5);
				String reply = result.getString(6);
				String truename = result.getString(7);
				String address = result.getString(8);
				String phone = result.getString(9);
				String email = result.getString(10);
				user.setUserId(usersid);
				user.setUsersName(name);
				user.setUsersPass(pass);
				user.setUsersRepass(repass);
				user.setUsersPassQuestion(question);
				user.setUsersAddress(address);
				user.setUsersPassReply(reply);
				user.setUsersTrueName(truename);
				user.setUsersE_mail(email);
				user.setUsersPhone(phone);
				arraylist.add(user);
			}
			result.close();
			stam.close();
			con.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return arraylist;
	}

	public ArrayList<UserClass> getUserByUserName(String s) {
		UserClass userClass = new UserClass();
		ArrayList<UserClass> arraylist = new ArrayList<UserClass>();

		try {
			PreparedStatement statement = con
					.prepareStatement("select * from users where usersName='" + s+ "'");
			ResultSet resultset = statement.executeQuery();

			while (resultset.next()) {

				int i = resultset.getInt(1);
				String s1 = resultset.getString(2);
				String s2 = resultset.getString(3);
				String s3 = resultset.getString(4);
				String s4 = resultset.getString(5);
				String s5 = resultset.getString(6);
				String s6 = resultset.getString(7);
				String s7 = resultset.getString(8);
				String s8 = resultset.getString(9);
				String s9 = resultset.getString(10);

				userClass.setUserId(i);
				userClass.setUsersName(s1);
				userClass.setUsersPass(s2);
				userClass.setUsersRepass(s3);
				userClass.setUsersPassQuestion(s4);
				userClass.setUsersPassReply(s5);
				userClass.setUsersTrueName(s6);
				userClass.setUsersAddress(s7);
				userClass.setUsersPhone(s8);
				userClass.setUsersE_mail(s9);
				arraylist.add(userClass);
			}
			resultset.close();
			statement.close();

		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return arraylist;
	}

	public void deleteUser(String s) {
		try {
			int a = Integer.parseInt(s);
			Statement stam = con.createStatement();
			stam.execute("delete * from users where usersId='" + a + "'");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
