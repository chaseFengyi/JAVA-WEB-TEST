package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.domain.Resource;

import com.utils.JdbcUtils;

public class ResourceDao {

	public List<Resource> getAllResource() throws SQLException
	{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Resource> resources = new ArrayList<Resource>();
		try
		{
			
			conn = JdbcUtils.getConnection();
			String sql = "select * from resource";
			 ps = conn.prepareStatement(sql);
			 rs = ps.executeQuery();
			while(rs.next())
			{
				Resource resource = new Resource();
				resource.setId(rs.getString("id"));
				resource.setName(rs.getString("name"));
				resource.setDescription(rs.getString("description"));
				resource.setCreateTime(rs.getString("createtime"));
				resource.setStatus(rs.getString("status"));
				resources.add(resource);
			}
		}
		finally
		{
			JdbcUtils.free(rs, ps, conn);	
		}
		return resources;
	}

	public Resource getResourceById(String id) throws SQLException {

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Resource resource = new Resource();
		try
		{
			
			conn = JdbcUtils.getConnection();
			String sql = "select * from resource where id=?";
			 ps = conn.prepareStatement(sql);
			 ps.setString(1, id);
			 rs = ps.executeQuery();
			while(rs.next())
			{
				
				resource.setId(rs.getString("id"));
				resource.setName(rs.getString("name"));
				resource.setDescription(rs.getString("description"));
				resource.setCreateTime(rs.getString("createtime"));
				resource.setStatus(rs.getString("status"));
				
			}
		}
		finally
		{
			JdbcUtils.free(rs, ps, conn);	
		}
		return resource;
	}

	public void updateResource(Resource resource) throws SQLException {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try
		{
			
			conn = JdbcUtils.getConnection();
			String sql = "update resource set name=?,description=?,createtime=?,status=? where id=?";
			 ps = conn.prepareStatement(sql);
			 ps.setString(1, resource.getName());
			 ps.setString(2, resource.getDescription());
			 ps.setString(3, resource.getCreateTime());
			 ps.setString(4, resource.getStatus());
			 ps.setString(5, resource.getId());
			 ps.executeUpdate();
			
		}
		finally
		{
			JdbcUtils.free(rs, ps, conn);	
		}
		
	}

	public void deleteById(String id) throws SQLException {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try
		{
			
			conn = JdbcUtils.getConnection();
			String sql = "delete from resource where id=?";
			 ps = conn.prepareStatement(sql);
			 ps.setString(1, id);
			 ps.executeUpdate();
			
		}
		finally
		{
			JdbcUtils.free(rs, ps, conn);	
		}
	}
}
