package com;
   //���л��ӿ�

public class AdminClass implements java.io.Serializable
{
    private int adminId;
    private String adminName;
    private String adminPass;


    public int getAdminId() {
        return adminId;
    }

    public String getAdminName() {
        return adminName;
    }

    public String getAdminPass() {
        return adminPass;
    }

    public void setAdminId(int adminId) {
        this.adminId = adminId;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }

    public void setAdminPass(String adminPass) {
        this.adminPass = adminPass;
    }

}
