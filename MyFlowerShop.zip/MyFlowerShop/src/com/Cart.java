package com;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
//������
public class Cart {
       private String name;//�û���ʶ
       private HashMap items;
       private int orderID;
       private float totalPrice;
       private Connection con;
       int ordersId=0;
       static CallableStatement cs=null;   //CallableStatement���ڵ��ô洢����
       static  Statement sta=null;
       static ResultSet res=null;
       public int getOrderID()
       {
    	   return orderID;
       }
       public  float getTotalPrice()
       {
    	   return  totalPrice;
       }
       public Cart()    //�������ݿ�  ��ɹ�ϣmap�ĳ�ʼ��
       {
    	   try {
			con=JBConnection.getConnection();
			System.out.println("���ݿ���سɹ�!");
			
		} catch (Exception e) {
		   e.printStackTrace();
		}
		items=new HashMap();
       }
       //������Ʒ�ķ���
       @SuppressWarnings("unchecked")
	public void addItem(String itemId,int quantity)
       {
    	   items.put(itemId,new Integer(quantity));//The method put(Object, Object)
       }
       //ɾ����Ʒ�ķ���
       public void removeItem(String itemId)
       {
    	   items.remove(itemId);
       }
       //������Ʒ�ķ���
       public void updateItem(String itemId,int quantity)
       {
    	   if(items.containsKey(itemId))
    		   items.remove(itemId);
    	   items.put(itemId, new Integer(quantity));
       }
       public HashMap getItem()
       {
    	   return this.items;
       }
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
      public void clear()
      {
    	  items.clear();
      }
      //���ɶ��� �����ɶ�����
      @SuppressWarnings("deprecation")
	public int getOrder(String s1,String s2)
      {
    	  String s3=new Date().toLocaleString();    
    	  try {
			cs=con.prepareCall("{call Pro_orders(?,?,?,?)}");  
			cs.setString(1, s1);
			cs.setString(2, s2);
			cs.setString(3, s3);
			cs.registerOutParameter(4, java.sql.Types.INTEGER);//registerOutParameter(x,y)Ϊע�ắ������һ������Ϊ"?"����ţ��˴����������ݿ���ֶ�������
		  cs.execute();
		  ordersId=cs.getInt(4);
		  System.out.println(ordersId);
    	  } catch (Exception e) {
			   e.printStackTrace();
		}
    	  return ordersId;
      }
      //���㵱ǰ���ﳵ����Ʒ���ܼ۸�
      public float calPrice(float totalprice)
      {
    	  return  this.totalPrice=totalprice;
    	  
      }
      public void addOrder(String orderName,String totalPrice)
      {
    	  try {
			String dateTime=new Date().toLocaleString();
			System.out.println(dateTime);
			PreparedStatement pst=con.prepareStatement("insert into orders values(?,?,?)");
			pst.setString(1, orderName);
			pst.setString(2, totalPrice);
			pst.setString(3, dateTime);
			int i=pst.executeUpdate();  //iΪ���������ݿ��м�����¼
			pst.close();
		} catch (Exception e) {
		   e.printStackTrace();
		}
      }
      //�洢��ǰ������Ʒ��ϸ
      public void saveItems(int i1,String s3,String s4,int i2)
      {
    	try {
			PreparedStatement  pst=con.prepareStatement("insert into ordersDetails(ordersId,goodsName" +
					",goodsPrice,goodsCount)  values(?,?,?,?)");
			pst.setInt(1,i1);
			pst.setString(2, s3);
			pst.setString(3, s4);
			pst.setInt(4, i2);
			int i=pst.executeUpdate();
			pst.close();
		} catch (Exception e) {
		    e.printStackTrace();
		}  
      }
      //�õ����ж���
      public Collection getOrders()
      {
    	  OrdersClass orders;
    	  ArrayList arrayList =new ArrayList();
    	  try {
			Statement sta=con.createStatement();
			ResultSet  res=sta.executeQuery("select * from orders");
			while(res.next())
			{
				orders=new OrdersClass();
				int ordersId=res.getInt(1);
				String usersName=res.getString(2);
				float ordersPrice=res.getFloat(3);
				String ordersDatetime=res.getString(4);
				orders.setOrdersId(ordersId);
				orders.setUsersName(usersName);
				orders.setOrdersPrice(ordersPrice);
				orders.setOrdersDatetime(ordersDatetime);
				arrayList.add(orders);   //�ӵ�ArrayList��
			}
			res.close();
			sta.close();
		} catch (Exception e) {
		   e.printStackTrace();
		}
		return arrayList;
      }
      //���ݶ���ID�õ�����
      public Collection getOrdersByOrdersId(String s)
      {
    	    int id=Integer.parseInt(s);
    	    OrdersClass orders;
    	    ArrayList arrayList =new ArrayList();
           try {
        	   Statement sta=con.createStatement();
   			ResultSet  res=sta.executeQuery("select * from orders where ordersId="+id);
   			while(res.next())
   			{
   				orders=new OrdersClass();
   				int ordersId=res.getInt(1);
   				String usersName=res.getString(2);
   				float ordersPrice=res.getFloat(3);
   				String ordersDatetime=res.getString(4);
   				orders.setOrdersId(ordersId);
   				orders.setUsersName(usersName);
   				orders.setOrdersPrice(ordersPrice);
   				orders.setOrdersDatetime(ordersDatetime);
   				arrayList.add(orders);   //�ӵ�ArrayList��
   			}
   			res.close();
   			sta.close();
		} catch (Exception e) {
		     e.printStackTrace();
		}
		return arrayList;
           } 
      //ͨ���û����õ�����
        public Collection  getOrdersByusersName(String s)
        {
        	 OrdersClass orders;
       	     ArrayList arrayList =new ArrayList();
       	     try {
				Statement  sta=con.createStatement();
				ResultSet  res=sta.executeQuery("select * from orders where usersName=' "+s+" ' ");
				while(res.next())
	   			{
	   				orders=new OrdersClass();
	   				int ordersId=res.getInt(1);
	   				String usersName=res.getString(2);
	   				float ordersPrice=res.getFloat(3);
	   				String ordersDatetime=res.getString(4);
	   				orders.setOrdersId(ordersId);
	   				orders.setUsersName(usersName);
	   				orders.setOrdersPrice(ordersPrice);
	   				orders.setOrdersDatetime(ordersDatetime);
	   				arrayList.add(orders);   //�ӵ�ArrayList��
	   			}
			} catch (Exception e) {
			   e.printStackTrace();
			}
			return  arrayList;
        }
        //���ݶ���ID ɾ������
        public void deleteOrder(String s)
        {
			try {
				int id=Integer.parseInt(s);
	        	Statement sta = con.createStatement();
				sta.execute("delete from orders where ordersId=' "+id+" ' ");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
        }
}
