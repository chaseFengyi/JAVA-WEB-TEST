package com;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;

public class AdminBean {
	private Connection con;
	AdminClass admin = new AdminClass();

	public AdminBean() {
		try {
			con = JBConnection.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void setAdminInfo(AdminClass admin) {
		this.admin = admin;
	}

	public void addAdminInfo() throws Exception {
		try {

			PreparedStatement stm = con
					.prepareStatement("insert into admin values(?,?)");
			stm.setString(1, admin.getAdminName());
			stm.setString(2, admin.getAdminPass());

			try {
				stm.executeQuery();
			} catch (Exception e) {
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public boolean checkAdminInfo() throws Exception {
		boolean flag = false;
		try {

			PreparedStatement stat = con
					.prepareStatement("select * from admin where adminName=? and adminPass=?");
			stat.setString(1, admin.getAdminName());
			stat.setString(2, admin.getAdminPass());
			ResultSet result = stat.executeQuery();

			if (result.next()) {
				flag = true;
			}

			result.close();
			stat.close();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return flag;
	}

	public AdminClass getAdminInfo() throws Exception {
		AdminClass admin1 = new AdminClass();
		try {
			PreparedStatement stat = con
					.prepareStatement("select * from admin where adminName=? and adminPass=?");
			stat.setString(1, admin.getAdminName());
			stat.setString(2, admin.getAdminPass());
			ResultSet result = stat.executeQuery();

			while (result.next()) {
				int id = result.getInt(1);
				String name = result.getString(2);
				String pass = result.getString(3);

				// System.out.println(name+"    "+sex);

				admin1.setAdminId(id);
				admin1.setAdminName(name);
				admin1.setAdminPass(pass);
			}
			result.close();
			stat.close();

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return admin1;
	}

	public Collection getAllUserInfo() {
		AdminClass admin;
		ArrayList<AdminClass> arraylist = new ArrayList<AdminClass>();
		try {
			Statement statement = con.createStatement();
			ResultSet resultset = statement.executeQuery("select * from admin");

			while (resultset.next()) {
				admin = new AdminClass();
				int id = resultset.getInt(1);
				String name = resultset.getString(2);
				String pass = resultset.getString(3);

				admin.setAdminId(id);
				admin.setAdminName(name);
				admin.setAdminPass(pass);

				arraylist.add(admin);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return arraylist;
	}

	public void deleteAdmin(String s) {
		try {
			int i = Integer.parseInt(s);

			Statement statement = con.createStatement();
			statement.execute("delete from admin where adminId='" + i + "'");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
