package com;

public class PageNumber {
	/*
	 * rowCount  �ܵļ�¼��
	 * pageSize   ÿҳ��ʾ�ļ�¼��
	 * showPage  ��������ʾ��ҳ����
	 * pageCount ��ҳ֮�����ҳ��
	 *  */
        int rowCount=1,pageSize=1,showPage=1,pageCount=1;
        public void setRowCount(int n)
        {
        	rowCount=n;
        }
        public int getRowCount()
        {
        	return rowCount;
        }
        public void setPageCount(int r,int p)
        {
        	rowCount=r;
        	pageSize=p;
        	int n=(rowCount%pageCount)==0? (rowCount/pageSize):(rowCount/pageSize+1);
        	pageCount=n;
        }
        public int getPageCount()
        {
        	return pageCount;
        }
        public void  setShowPage(int n)
        {
        	showPage=n;
        }
        public int getShowPage()
        {
        	return showPage;
        }
        public void setPageSize(int n)
        {
        	pageSize=n;
        }
        public int getPageSize()
        {
        	return pageSize;
        }
}
