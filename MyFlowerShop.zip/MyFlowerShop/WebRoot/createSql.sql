create database buyflowers;
create table admin(	adminId int(14) primary key auto_increment,
	adminName varchar(20),
	adminPass varchar(20);
create table goods(	goodsId int(14) primary key auto_increment,
	goodsName varchar(30),
	goodsmaterial varchar(30),
	goodsPackage varchar(30),
	goodsLanguage varchar(30),
	goodsPrice float(8,0),
	goodsCent varchar(20),
	goodsScope varchar(20),
	goodsPlace varchar(30),
	goodsHabitus varchar(30),
	sortName varchar(20));
create table orders(	ordersId int(14) primary key auto_increment,
	usersName varchar(20) not null,
	ordersPrice float(8,0) not null,
	ordersDatetime varchar(20) not null);
create table ordersdetails(	ordersId int(14) primary key auto_increment,
	goodsName varchar(30),
	goodsPrice varchar(8),
	goodsCount int(100));
create table users(	usersId int(11) primary key auto_increment
	usersName varchar(20) not null,
	usersPass varchar(20) not null,
	usersRepass varchar(20) not null,
	usersPassQuestion varchar(40),
	usersPassReply varchar(40),
	usersTrueName varchar(20) not null,
	usersAddress varchar(50) not null,
	usersPhone varchar(12) not null,
	usersE_mail varchar(20));