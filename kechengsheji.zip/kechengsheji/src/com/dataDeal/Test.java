package com.dataDeal;

public class Test {
	public static void main(String[] args) {
		int i = 5;
		try{
//			i = 5;
			System.out.println(i);
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
}
